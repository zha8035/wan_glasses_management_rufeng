package photo_save;

import java.awt.Image;
import java.awt.Graphics;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JFrame;

import com.computer_net.model.ImagSave;
public class ImageGet extends JFrame{
    /**
	 * 
	 */
	static File f=null;
	private static final long serialVersionUID = 1L;
	public ImageGet(ImagSave IS){
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
//	public static void main(String args[]) {
//		ImagSave IS1=new ImagSave();
//		getIm(IS1);
//	}
    
	public static boolean getIm(ImagSave IS){
        try {
            Class.forName("com.mysql.jdbc.Driver").newInstance();
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        String user = "root";
        String pd = "3041992";
        String url = "jdbc:mysql://localhost:3306/db_database01?characterEncoding=utf-8";
        Connection connection = null;
        
        
        try {
            connection = DriverManager.getConnection(url, user, pd);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        Statement statement = null;
        ResultSet resultSet = null;
        InputStream inputStream = null;
        ImagSave IS1=new ImagSave();
        try {
            statement = connection.createStatement();
            String sql = "select photo from im_store where username='"+IS1.getUsername()+"'and cir='"+IS1.getCir()+"'and date='"+IS1.getDate()+"';";
            resultSet = statement.executeQuery(sql);
            if(resultSet.next()){
            inputStream = resultSet.getBinaryStream("photo");
            ImageUtil.readBlob(inputStream, f);
            return true;
            }else{
            	System.out.println("�������");
            	return false;
            	}
            	
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("����쳣");
            return false;
        } finally {
            try {
                if (inputStream != null)
                    inputStream.close();
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                try {
                    if (resultSet != null)
                        resultSet.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                } finally {
                    if (statement != null)
                        if (statement != null)
                            try {
                                statement.close();
                            } catch (SQLException e) {
                                e.printStackTrace();
                            } finally {
                                if (connection != null)
                                    try {
                                        connection.close();
                                    } catch (SQLException e) {
                                        e.printStackTrace();
                                    }
                            }
                }
            }
        }
    }
    public void paint(Graphics g) {

    	String fn=f.getName();
    	//ȡ��ͼƬ����
        Image image = getToolkit().getImage(fn);
        //��ͼ
        g.drawImage(image, 0, 0, this);
        }
	}
