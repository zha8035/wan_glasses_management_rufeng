package photo_save;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.Image;

public class imageShow extends Frame {
    String filename;

    public imageShow(String filename) {

	setSize(470, 350);
    setVisible(true);
    this.filename = filename;
    }
    public void paint(Graphics g) {

	//ȡ��ͼƬ����
    Image image = getToolkit().getImage(filename);
    //��ͼ
    g.drawImage(image, 0, 0, this);
    }
    public static void main(String args[]) {
    new imageShow("D:/workspace3.4/javamedia/src/com/test/image/test.jpg");
    }
}