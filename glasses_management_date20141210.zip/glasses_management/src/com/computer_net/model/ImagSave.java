package com.computer_net.model;

public class ImagSave {
	private String username;// ����
    private String cir;// �Ƴ�����
    private String date;// ����
    private String store;// ͼƬ

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getCir() {
        return cir;
    }

    public void setCir(String cir) {
        this.cir = cir;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }
    
    public String getStore() {
        return store;
    }

    public void setStore(String store) {
        this.store =store;
    }
}
