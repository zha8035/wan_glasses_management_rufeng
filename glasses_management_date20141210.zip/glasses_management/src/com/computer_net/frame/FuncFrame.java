package com.computer_net.frame;

import java.awt.EventQueue;
import java.io.*;
import java.awt.event.*;
import java.util.regex.Pattern;

import javax.swing.*;

import photo_save.ImageGet;
import photo_save.ImageInsert;

import com.computer_net.util.DBHelper1;
import com.computer_net.util.SwingUtil;
import com.computer_net.model.ImagSave;

public class FuncFrame extends JFrame{

	/**
	 * 
	 */
	private static final long serialVersionUID = 2515434742099260667L;
	public  JFrame FuncFrame;
	private JTextField usernameTextField;
	private JTextField cirTextField;
	private JTextField dateTextField;
	private static File file=null;
	private JTextField usernamespTextField;
	private JTextField cirspTextField;
	private JTextField datespTextField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FuncFrame window = new FuncFrame();
					window.FuncFrame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public FuncFrame() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		FuncFrame = new JFrame();
		FuncFrame.setTitle("\u6B22\u8FCE\u8FDB\u5165\u773C\u955C\u53C2\u6570\u767B\u8BB0\u7CFB\u7EDF");
		FuncFrame.setBounds(100, 100, 556, 423);
		FuncFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		FuncFrame.getContentPane().setLayout(null);
		
		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane.setBounds(0, 0, 538, 376);
		FuncFrame.getContentPane().add(tabbedPane);
		
		JPanel GlassInputPanel = new JPanel();
		tabbedPane.addTab("\u773C\u955C\u53C2\u6570\u8F93\u5165", null, GlassInputPanel, null);
		GlassInputPanel.setLayout(null);
		
		JLabel GlassInputLabel = new JLabel("");
		GlassInputLabel.setBounds(0, 0, 427, 282);
		GlassInputPanel.add(GlassInputLabel);
		GlassInputLabel.setToolTipText("");
		
		JPanel CheckPanel = new JPanel();
		tabbedPane.addTab("\u60A3\u8005\u4FE1\u606F\u67E5\u8BE2", null, CheckPanel, null);
		
		JLabel CheckLable = new JLabel("");
		CheckPanel.add(CheckLable);
		
		JPanel AnalysePanel = new JPanel();
		tabbedPane.addTab("\u53C2\u6570\u5206\u6790", null, AnalysePanel, null);
		
		JLabel AnalyseLable = new JLabel("");
		AnalysePanel.add(AnalyseLable);
		
		JPanel ScanPanel = new JPanel();
		tabbedPane.addTab("\u626B\u63CF\u5BFC\u5165\u7CFB\u7EDF", null, ScanPanel, null);
		SpringLayout sl_ScanPanel = new SpringLayout();
		ScanPanel.setLayout(sl_ScanPanel);
		
		JLabel usernameLable = new JLabel("\u7528\u6237\u59D3\u540D");
		sl_ScanPanel.putConstraint(SpringLayout.NORTH, usernameLable, 69, SpringLayout.NORTH, ScanPanel);
		sl_ScanPanel.putConstraint(SpringLayout.WEST, usernameLable, 125, SpringLayout.WEST, ScanPanel);
		ScanPanel.add(usernameLable);
		
		usernameTextField = new JTextField();
		sl_ScanPanel.putConstraint(SpringLayout.NORTH, usernameTextField, -3, SpringLayout.NORTH, usernameLable);
		ScanPanel.add(usernameTextField);
		usernameTextField.setColumns(10);
		
		JLabel cirLabel = new JLabel("\u7597\u7A0B\u671F\u6570");
		sl_ScanPanel.putConstraint(SpringLayout.WEST, cirLabel, 0, SpringLayout.WEST, usernameLable);
		ScanPanel.add(cirLabel);
		
		cirTextField = new JTextField();
		sl_ScanPanel.putConstraint(SpringLayout.EAST, usernameTextField, 0, SpringLayout.EAST, cirTextField);
		sl_ScanPanel.putConstraint(SpringLayout.NORTH, cirTextField, 114, SpringLayout.NORTH, ScanPanel);
		sl_ScanPanel.putConstraint(SpringLayout.WEST, cirTextField, 88, SpringLayout.EAST, cirLabel);
		sl_ScanPanel.putConstraint(SpringLayout.NORTH, cirLabel, 3, SpringLayout.NORTH, cirTextField);
		ScanPanel.add(cirTextField);
		cirTextField.setColumns(10);
		
		JLabel dateLabel = new JLabel("\u56FE\u7247\u65E5\u671F");
		sl_ScanPanel.putConstraint(SpringLayout.WEST, dateLabel, 0, SpringLayout.WEST, usernameLable);
		ScanPanel.add(dateLabel);
		
		dateTextField = new JTextField();
		sl_ScanPanel.putConstraint(SpringLayout.NORTH, dateTextField, 23, SpringLayout.SOUTH, cirTextField);
		sl_ScanPanel.putConstraint(SpringLayout.WEST, dateTextField, 88, SpringLayout.EAST, dateLabel);
		sl_ScanPanel.putConstraint(SpringLayout.NORTH, dateLabel, 3, SpringLayout.NORTH, dateTextField);
		ScanPanel.add(dateTextField);
		dateTextField.setColumns(10);
		
		JLabel storeLabel = new JLabel("\u5BFC\u5165\u56FE\u7247");
		sl_ScanPanel.putConstraint(SpringLayout.EAST, storeLabel, 0, SpringLayout.EAST, usernameLable);
		ScanPanel.add(storeLabel);
		
		JButton storeButton = new JButton("\u6253\u5F00");
		sl_ScanPanel.putConstraint(SpringLayout.WEST, storeButton, 88, SpringLayout.EAST, storeLabel);
		sl_ScanPanel.putConstraint(SpringLayout.EAST, storeButton, -174, SpringLayout.EAST, ScanPanel);
		sl_ScanPanel.putConstraint(SpringLayout.NORTH, storeLabel, 4, SpringLayout.NORTH, storeButton);
		sl_ScanPanel.putConstraint(SpringLayout.NORTH, storeButton, 20, SpringLayout.SOUTH, dateTextField);
		storeButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				loadfile();
			}
		});
		ScanPanel.add(storeButton);
		
		JButton confirmButton = new JButton("\u786E\u5B9A");
		sl_ScanPanel.putConstraint(SpringLayout.SOUTH, confirmButton, -29, SpringLayout.SOUTH, ScanPanel);
		sl_ScanPanel.putConstraint(SpringLayout.EAST, confirmButton, -128, SpringLayout.EAST, ScanPanel);
		ScanPanel.add(confirmButton);
		confirmButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                do_confirmButton_actionPerformed(e);
            }
        });
		
		JButton cancelButton = new JButton("\u53D6\u6D88");
		sl_ScanPanel.putConstraint(SpringLayout.NORTH, cancelButton, 0, SpringLayout.NORTH, confirmButton);
		sl_ScanPanel.putConstraint(SpringLayout.WEST, cancelButton, 32, SpringLayout.EAST, confirmButton);
		ScanPanel.add(cancelButton);
		
		JPanel ShowPanel = new JPanel();
		tabbedPane.addTab("\u56FE\u7247\u67E5\u770B", null, ShowPanel, null);
		
		JLabel usernamespLable = new JLabel("\u7528\u6237\u59D3\u540D");
		ShowPanel.add(usernamespLable);
		
		usernamespTextField = new JTextField();
		usernamespTextField.setColumns(10);
		ShowPanel.add(usernamespTextField);
		
		JLabel cirspLable = new JLabel("\u7597\u7A0B\u671F\u6570");
		ShowPanel.add(cirspLable);
		
		cirspTextField = new JTextField();
		cirspTextField.setColumns(10);
		ShowPanel.add(cirspTextField);
		
		JLabel datespLable = new JLabel("\u56FE\u7247\u65E5\u671F");
		ShowPanel.add(datespLable);
		
		datespTextField = new JTextField();
		datespTextField.setColumns(10);
		ShowPanel.add(datespTextField);
		
		JButton spconfirmButton = new JButton("\u786E\u5B9A");
		spconfirmButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                do_spconfirmButton_actionPerformed(e);
            }
        });
		ShowPanel.add(spconfirmButton);
		
		JButton spcancelButton = new JButton("\u53D6\u6D88");
		ShowPanel.add(spcancelButton);
		spcancelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                do_spcancelButton_actionPerformed(e);
            }
        });
		setLocation(SwingUtil.centreContainer(getSize()));
	}
	
	public static void loadfile(){
		JFileChooser fc=new JFileChooser();
		int r=fc.showOpenDialog(null);
		if(r==JFileChooser.APPROVE_OPTION);{
			file=fc.getSelectedFile();
		}
	}
	protected void do_confirmButton_actionPerformed(ActionEvent e){
		String username=usernameTextField.getText().trim();//���ͼƬ�Ǽ��û�����
		String cir=cirTextField.getText().trim();//����û�������Ƴ���
		String date=dateTextField.getText().trim();//���ͼƬ��д������
		
		//��ʼ���зǿ�У��
		if (username.isEmpty()) {// �ж��û����Ƿ�Ϊ��
	        JOptionPane.showMessageDialog(this, "�û�������Ϊ�գ�","������Ϣ",JOptionPane.WARNING_MESSAGE);
	        return;
	    }
	    if (new String(cir).isEmpty()) {// �ж��Ƴ������Ƿ�Ϊ��
	        JOptionPane.showMessageDialog(this, "�Ƴ���������Ϊ�գ�","������Ϣ",JOptionPane.WARNING_MESSAGE);
	        return;
	    }
	    if (date.isEmpty()) {// �ж���Ƭ�����Ƿ�Ϊ��
	        JOptionPane.showMessageDialog(this, "��Ƭ���ڲ���Ϊ�գ�", "������Ϣ", JOptionPane.WARNING_MESSAGE);
	        return;
	    }
	 // У���û����Ƿ�Ϸ�
	    if (!Pattern.matches("\\w{5,15}", username)) {
	        JOptionPane.showMessageDialog(this, "������Ϸ����û�����", "������Ϣ", JOptionPane.WARNING_MESSAGE);
	        return;
	    }
	    // У���Ƴ������Ƿ�Ϸ�
	    if (!Pattern.matches("\\w", cir)) {
	        JOptionPane.showMessageDialog(this, "������Ϸ����Ƴ�������", "������Ϣ", JOptionPane.WARNING_MESSAGE);
	        return;
	    }
	    // У����Ƭ�����Ƿ�Ϸ�
	    if (!Pattern.matches("\\d*", date)) {
	        JOptionPane.showMessageDialog(this, "������Ϸ�����Ƭ���ڣ�", "������Ϣ", JOptionPane.WARNING_MESSAGE);
	        return;
	    }
	    // У���û����Ƿ����
	    if (DBHelper1.exists(username)) {
	        if(DBHelper1.exists(cir)){
	        	JOptionPane.showMessageDialog(this, "���û����Ƴ��Ѿ�����", "������Ϣ", JOptionPane.WARNING_MESSAGE);
	            return;
	        }
	    }
	    ImagSave IS= new ImagSave();
	    IS.setUsername(username);
	    IS.setCir(cir);
	    IS.setDate(date);
	    String path=file.getAbsolutePath();
	    IS.setStore(path);
	    if (ImageInsert.main(IS)) {
	        JOptionPane.showMessageDialog(this, "ͼƬ��Ϣ����ɹ���", "��ʾ��Ϣ", JOptionPane.INFORMATION_MESSAGE);
	        return;
	    } else {
	        JOptionPane.showMessageDialog(this, "ͼƬ��Ϣ����ʧ�ܣ�", "������Ϣ", JOptionPane.WARNING_MESSAGE);
	        return;
	    } 
	}
	
	protected void do_cancelButton_actionPerformed(ActionEvent e) {
	    System.exit(0);// ��ֹ����
	}
	
	protected void do_spconfirmButton_actionPerformed(ActionEvent e) {
		String usernamesp=usernamespTextField.getText().trim();//���ͼƬ�Ǽ��û�����
		String cirsp=cirspTextField.getText().trim();//����û�������Ƴ���
		String datesp=datespTextField.getText().trim();//���ͼƬ��д������
		
		//��ʼ���зǿ�У��
		if (usernamesp.isEmpty()) {// �ж��û����Ƿ�Ϊ��
	        JOptionPane.showMessageDialog(this, "�û�������Ϊ�գ�","������Ϣ",JOptionPane.WARNING_MESSAGE);
	        return;
	    }
	    if (new String(cirsp).isEmpty()) {// �ж��Ƴ������Ƿ�Ϊ��
	        JOptionPane.showMessageDialog(this, "�Ƴ���������Ϊ�գ�","������Ϣ",JOptionPane.WARNING_MESSAGE);
	        return;
	    }
	    if (datesp.isEmpty()) {// �ж���Ƭ�����Ƿ�Ϊ��
	        JOptionPane.showMessageDialog(this, "��Ƭ���ڲ���Ϊ�գ�", "������Ϣ", JOptionPane.WARNING_MESSAGE);
	        return;
	    }
	 // У���û����Ƿ�Ϸ�
	    if (!Pattern.matches("\\w{5,15}", usernamesp)) {
	        JOptionPane.showMessageDialog(this, "������Ϸ����û�����", "������Ϣ", JOptionPane.WARNING_MESSAGE);
	        return;
	    }
	    // У���Ƴ������Ƿ�Ϸ�
	    if (!Pattern.matches("\\w", cirsp)) {
	        JOptionPane.showMessageDialog(this, "������Ϸ����Ƴ�������", "������Ϣ", JOptionPane.WARNING_MESSAGE);
	        return;
	    }
	    // У����Ƭ�����Ƿ�Ϸ�
	    if (!Pattern.matches("\\d*", datesp)) {
	        JOptionPane.showMessageDialog(this, "������Ϸ�����Ƭ���ڣ�", "������Ϣ", JOptionPane.WARNING_MESSAGE);
	        return;
	    }
	    // У���û����Ƿ����
	    if (DBHelper1.exists(usernamesp)) {
	        if(DBHelper1.exists(cirsp)){
	        	JOptionPane.showMessageDialog(this, "���û����Ƴ��Ѿ�����", "������Ϣ", JOptionPane.WARNING_MESSAGE);
	            return;
	        }
	    }
	    ImagSave IS1= new ImagSave();
	    IS1.setUsername(usernamesp);
	    IS1.setCir(cirsp);
	    IS1.setDate(datesp);
	    //String path=file.getAbsolutePath();
	    //IS1.setStore(path);
	    if (ImageGet.getIm(IS1)) {
	        JOptionPane.showMessageDialog(this, "ͼƬ��Ϣ��ʾ�ɹ���", "��ʾ��Ϣ", JOptionPane.INFORMATION_MESSAGE);
	        return;
	    } else {
	        JOptionPane.showMessageDialog(this, "ͼƬ��Ϣ��ʾʧ�ܣ�", "������Ϣ", JOptionPane.WARNING_MESSAGE);
	        return;
	    } 
	}
	protected void do_spcancelButton_actionPerformed(ActionEvent e) {
	    System.exit(0);// ��ֹ����
    }
}
